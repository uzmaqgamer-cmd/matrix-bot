// Offline sanity tests for classifier + matrix + watchlist logic.
// Run with: node test/logic.test.js

const { classify } = require('../src/classifier');
const { lookupRow } = require('../src/matrix');
const watchlist = require('../src/watchlist');

let pass = 0, fail = 0;
function check(label, cond) {
  if (cond) { pass++; console.log(`  PASS: ${label}`); }
  else { fail++; console.log(`  FAIL: ${label}`); }
}

console.log('--- Test 1: classify a clear PUMP scenario (row 2: OI up, price up, funding stable) ---');
{
  const result = classify({
    priceSeries: [100, 105, 110, 115, 120],   // +20% -> RISING (threshold 1.5%)
    oiSeries: [1000, 1020, 1040, 1060, 1080], // +8%  -> RISING (threshold 3%)
    fundingSeries: [0.01, 0.011],             // +0.001pp -> STABLE (threshold 0.02pp)
  });
  check('oi = RISING', result.oi === 'RISING');
  check('price = RISING', result.price === 'RISING');
  check('funding = STABLE', result.funding === 'STABLE');
  const row = lookupRow(result.oi, result.price, result.funding);
  check('matches row #2 (PUMP, healthy)', row.row === 2 && row.outlook === 'PUMP');
}

console.log('\n--- Test 2: classify a clear DUMP scenario (row 17: OI stable, price down, funding stable) ---');
{
  const result = classify({
    priceSeries: [100, 97, 94, 91, 88],       // -12% -> FALLING
    oiSeries: [1000, 1005, 998, 1002, 999],   // ~0%  -> STABLE
    fundingSeries: [0.02, 0.019],             // -0.001pp -> STABLE
  });
  const row = lookupRow(result.oi, result.price, result.funding);
  check('matches row #17 (DUMP, weak low conviction)', row.row === 17 && row.outlook === 'DUMP');
}

console.log('\n--- Test 3: replicate the ESPORTSUSDT scenario from the chart (OI crashing, price falling, funding diving negative) ---');
{
  // All three metrics falling together -> row 15 (BIG_COMING: short covering into weakness),
  // NOT a clean DUMP row. This is correct and useful: it flags this as a watch-list case,
  // not an immediate alert, because the negative funding + falling OI combo can still snap
  // into a bounce (shorts covering) before continuing down.
  const result = classify({
    priceSeries: [0.0374, 0.0350, 0.0320, 0.0300, 0.0290], // sharp fall -> FALLING
    oiSeries: [2.6, 2.4, 2.0, 1.8, 1.7],                   // OI/MCap ratio crashing -> FALLING
    fundingSeries: [0.05, -0.175],                          // funding diving negative -> FALLING
  });
  const row = lookupRow(result.oi, result.price, result.funding);
  console.log(`  -> Matched row #${row.row}: ${row.outlook} — ${row.meaning}`);
  check('matches row #15 (BIG_COMING, short covering into weakness)', row.row === 15 && row.outlook === 'BIG_COMING');
}

console.log('\n--- Test 4: watchlist lifecycle — divergence -> escalation to DUMP ---');
{
  const row10 = lookupRow('RISING', 'FALLING', 'RISING'); // row 10: crowded shorts, squeeze risk
  const a1 = watchlist.update('TESTUSDT', row10);
  check('first divergence hit -> ADDED', a1.type === 'ADDED');
  check('row 10 flagged HIGH priority', a1.priority === 'HIGH');

  const a2 = watchlist.update('TESTUSDT', row10);
  check('still divergent -> STILL_WATCHING', a2.type === 'STILL_WATCHING');

  const dumpRow = lookupRow('RISING', 'FALLING', 'STABLE'); // row 11: DUMP, healthy downtrend
  const a3 = watchlist.update('TESTUSDT', dumpRow);
  check('resolves to DUMP -> ESCALATED', a3.type === 'ESCALATED');
  check('remembers origin row 10', a3.originRow === 10);
}

console.log('\n--- Test 5: watchlist lifecycle — divergence resolves to false alarm ---');
{
  const row9 = lookupRow('STABLE', 'RISING', 'FALLING'); // row 9: divergence
  watchlist.update('FAKEUSDT', row9);
  const stableRow = lookupRow('STABLE', 'STABLE', 'STABLE'); // row 26: true equilibrium
  const a = watchlist.update('FAKEUSDT', stableRow);
  check('resolves to STABLE -> DROPPED_STABLE', a.type === 'DROPPED_STABLE');
}

console.log('\n--- Test 6: watchlist timeout / stale expiry ---');
{
  const config = require('../src/config');
  const row25 = lookupRow('STABLE', 'STABLE', 'RISING'); // row 25: coiling, upside lean
  watchlist.update('STALEUSDT', row25); // cyclesWatched = 0 (ADDED)
  let last;
  for (let i = 0; i < config.watchlistTimeoutCycles; i++) {
    last = watchlist.update('STALEUSDT', row25); // increments cyclesWatched each call
  }
  check('expires after watchlistTimeoutCycles', last.type === 'EXPIRED');
}

console.log(`\n=== ${pass} passed, ${fail} failed ===`);
process.exit(fail > 0 ? 1 : 0);
