# Matrix Signal Bot

Scans Binance USDT-M perpetuals, classifies OI / Price / Funding Rate direction over a
lookback window, matches the combination against your 27-row Market Context Matrix, and
sends Telegram alerts. Signal-only — does not place trades.

## How it works

1. **Background scan** (every 5 min by default) — pulls all top-volume perps, classifies each
   as RISING/STABLE/FALLING for OI, price, and funding, and matches the matrix row.
2. **Watch-list tier** — if a pair lands on one of the 14 "SOMETHING BIG COMING" rows, it's
   added to a watch-list and polled on a tighter interval (1 min default) instead of waiting
   for the next full scan.
3. **Escalation** — while watching, if the pair resolves into a clean PUMP or DUMP row, it
   fires a real alert to Telegram tagged with which divergence row predicted it and how many
   cycles ago.
4. **Timeout** — if a watched pair sits in divergence too long without resolving (20 cycles
   default, ~20 min), it's dropped as stale/chop, not carried forever.

High-conviction divergence rows (#10, #16, #19, #21 — squeeze setups) are flagged HIGH
priority vs MEDIUM for the rest.

## Setup

```bash
cd matrix-signal-bot
npm install    # no external deps currently — uses Node 18+ native fetch
cp .env.example .env
# fill in TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID in .env
npm test       # run offline logic tests first — should print "13 passed, 0 failed"
npm start
```

Without Telegram credentials set, the bot still runs and logs everything to console instead
of sending — useful for a dry run before wiring up delivery.

## Deploying on Replit (matches your other tools)

1. Create a new Node.js Repl, upload this project.
2. Add `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` as Replit Secrets (not `.env` — Replit
   secrets are the equivalent and don't get committed).
3. Set the run command to `node src/index.js`.
4. Use Replit's "Always On" / a keep-alive ping (same pattern you're probably already using
   for QUANTEX) if you're on a plan without dedicated always-on hosting.

## Before you trust this live — read this

I built the classifier and matrix logic and verified it against the offline test suite
(`test/logic.test.js`, 13/27 matrix combinations spot-checked including the exact ESPORTSUSDT
scenario from your chart). **I have not backtested it against real historical Binance data** —
this sandbox can't reach `fapi.binance.com`, so the Binance API client (`src/binanceClient.js`)
is untested against live data.

Before running this on real signals:

1. **Run it in log-only mode first** (no Telegram creds) for at least a day and eyeball the
   output against charts you're already watching. Does row-matching line up with what you'd
   call it manually?
2. **Tune the thresholds in `src/config.js`.** The defaults (price 1.5%, OI 3%, funding 0.02pp,
   20-candle lookback on 15m candles) are reasonable starting guesses, not validated numbers.
   Low-liquidity pairs like ESPORTS will need looser thresholds than BTC/ETH or you'll get
   spammed with noise.
3. **Watch the false-alarm rate on the watch-list tier.** If most divergence hits resolve to
   `DROPPED_STABLE` instead of `ESCALATED`, thresholds are too tight (triggering on noise).
   If nothing ever escalates, they might be too loose.
4. **Funding rate lookback is on a different clock than price/OI** — funding settles every 8h,
   not every candle, so `fundingLookbackPeriods` (default 3 = ~24h) is independent from
   `lookbackCandles`. Worth sanity-checking this assumption against Binance's actual funding
   schedule for the pairs you care about (some altcoins settle every 4h).

## File structure

```
src/
  config.js          — all tunable thresholds, intervals, and settings
  matrix.js           — the 27-row lookup table, transcribed from your photo
  classifier.js        — turns raw price/OI/funding series into RISING/STABLE/FALLING
  binanceClient.js      — Binance Futures API calls (price, OI, funding)
  watchlist.js            — divergence tracking, escalation, timeout logic
  telegram.js               — message formatting + delivery
  index.js                    — main scan loop, wires everything together
test/
  logic.test.js               — offline tests, no network required
```
