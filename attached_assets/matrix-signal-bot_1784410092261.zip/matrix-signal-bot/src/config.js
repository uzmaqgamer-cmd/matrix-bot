// ─────────────────────────────────────────────────────────────
// CONFIG — tune these before trusting live signals.
// Nothing here is "correct" out of the box. Backtest first.
// ─────────────────────────────────────────────────────────────

module.exports = {
  // Which pairs to scan on the normal (slow) cycle.
  // 'ALL_USDT_PERP' pulls every Binance USDT-M perpetual automatically.
  // Or hardcode a list: ['BTCUSDT', 'ETHUSDT', 'ESPORTSUSDT', ...]
  scanMode: 'ALL_USDT_PERP',
  topNByVolume: 150, // if scanMode is ALL_USDT_PERP, only scan the top N by 24h quote volume (keeps API load sane)

  // Polling intervals (ms)
  normalScanIntervalMs: 5 * 60 * 1000,   // background scan of everything — 5 min
  watchlistScanIntervalMs: 60 * 1000,    // tight polling for pairs already flagged as divergent — 1 min

  // Lookback window (number of candles) used to measure "RISING / STABLE / FALLING"
  // for PRICE and OPEN INTEREST.
  lookbackCandles: 20,
  candleInterval: '15m', // Binance kline interval used for the price/OI lookback series
  oiPeriod: '15m',       // must be one of Binance's supported OI-history periods: 5m/15m/30m/1h/2h/4h/6h/12h/1d

  // Funding settles on its own schedule (usually every 8h), not on the candleInterval —
  // so it needs its own lookback measured in "number of past funding settlements," not candles.
  // 3 = compare current funding rate to 3 settlements ago (~24h at an 8h funding interval).
  fundingLookbackPeriods: 3,

  // % change thresholds over the lookback window to call a metric RISING or FALLING.
  // Anything between -threshold and +threshold is STABLE.
  // These are guesses — validate against real data before trusting them.
  thresholds: {
    price: 1.5,     // % price change
    oi: 3.0,        // % open interest change
    funding: 0.02,  // absolute percentage-point change in funding rate (funding is already small, e.g. 0.01%)
  },

  // The "SOMETHING BIG COMING" rows from the matrix (row numbers, 1-indexed as in the photo).
  // These trigger the watch-list tier instead of an immediate alert.
  // Note: the matrix actually has 14 of these (row 25 "coiling, upside lean" included) —
  // double-check against src/matrix.js if you ever edit this list by hand.
  divergenceRows: [3, 9, 10, 12, 13, 15, 16, 19, 20, 21, 22, 24, 25, 27],

  // Highest-conviction divergence rows — compression before expansion.
  // These get a HIGH priority tag; everything else in divergenceRows is MEDIUM.
  highPriorityDivergenceRows: [10, 16, 19, 21],

  // How many watchlist scan cycles a pair can stay flagged before being dropped as stale
  // (i.e. divergence never resolved into a real move — probably just chop).
  watchlistTimeoutCycles: 20, // at 1 min/cycle default, ~20 minutes

  // Telegram delivery
  telegram: {
    botToken: process.env.TELEGRAM_BOT_TOKEN || '',
    chatId: process.env.TELEGRAM_CHAT_ID || '',
  },

  binance: {
    futuresBase: 'https://fapi.binance.com',
  },
};
