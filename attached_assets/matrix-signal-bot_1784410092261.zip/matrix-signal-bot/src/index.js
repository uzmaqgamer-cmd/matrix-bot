const config = require('./config');
const binance = require('./binanceClient');
const { classify } = require('./classifier');
const { lookupRow } = require('./matrix');
const watchlistModule = require('./watchlist');
const telegram = require('./telegram');

/** Fetch and classify one symbol. Returns the matched matrix row, or null on data failure. */
async function scanSymbol(symbol) {
  try {
    const [priceSeries, oiSeries, fundingSeries] = await Promise.all([
      binance.getCloseSeries(symbol, config.candleInterval, config.lookbackCandles),
      binance.getOpenInterestSeries(symbol, config.oiPeriod, config.lookbackCandles),
      binance.getFundingRateSeries(symbol, config.fundingLookbackPeriods + 1),
    ]);

    if (priceSeries.length < 2 || oiSeries.length < 2 || fundingSeries.length < 2) {
      console.warn(`[${symbol}] insufficient data, skipping this cycle`);
      return null;
    }

    const { oi, price, funding } = classify({ priceSeries, oiSeries, fundingSeries });
    return lookupRow(oi, price, funding);
  } catch (err) {
    console.warn(`[${symbol}] scan failed: ${err.message}`);
    return null;
  }
}

/** Handle the watchlist action for one symbol's scan result. */
async function handleAction(symbol, matrixRow) {
  const action = watchlistModule.update(symbol, matrixRow);

  switch (action.type) {
    case 'ADDED':
      console.log(`[WATCH] ${symbol} → row #${matrixRow.row} (${action.priority}) — ${matrixRow.meaning}`);
      await telegram.sendMessage(telegram.formatAddedMessage(action));
      break;
    case 'ESCALATED':
      console.log(`[ALERT] ${symbol} → ${matrixRow.outlook} (was row #${action.originRow}, ${action.cyclesElapsed} cycles ago)`);
      await telegram.sendMessage(telegram.formatEscalatedMessage(action));
      break;
    case 'DROPPED_STABLE':
      console.log(`[DROP] ${symbol} → resolved to STABLE, false alarm`);
      break;
    case 'EXPIRED':
      console.log(`[EXPIRE] ${symbol} → divergence never resolved after ${action.cyclesWatched} cycles, dropping`);
      break;
    case 'STILL_WATCHING':
      console.log(`[WATCH] ${symbol} → still on row #${matrixRow.row} (cycle ${action.cyclesWatched})`);
      break;
    case 'NONE':
    default:
      // not divergent, not on watchlist — nothing to report
      break;
  }
  return action;
}

/** Full background scan across the configured symbol universe. */
async function runFullScan() {
  let symbols;
  if (config.scanMode === 'ALL_USDT_PERP') {
    symbols = await binance.getTopSymbolsByVolume(config.topNByVolume);
  } else {
    symbols = config.scanMode; // treat as an explicit array
  }

  console.log(`\n=== Full scan: ${symbols.length} pairs @ ${new Date().toISOString()} ===`);
  for (const symbol of symbols) {
    const matrixRow = await scanSymbol(symbol);
    if (matrixRow) await handleAction(symbol, matrixRow);
  }
}

/** Tight scan of only pairs currently on the watchlist. */
async function runWatchlistScan() {
  const snapshot = watchlistModule.getWatchlistSnapshot();
  if (snapshot.length === 0) return;

  console.log(`\n--- Watchlist scan: ${snapshot.length} pairs @ ${new Date().toISOString()} ---`);
  for (const { symbol } of snapshot) {
    const matrixRow = await scanSymbol(symbol);
    if (matrixRow) await handleAction(symbol, matrixRow);
  }
}

async function main() {
  console.log('Matrix Signal Bot starting...');
  console.log(`Mode: ${config.scanMode} | Top N: ${config.topNByVolume}`);
  console.log(`Thresholds: price=${config.thresholds.price}% oi=${config.thresholds.oi}% funding=${config.thresholds.funding}pp`);
  console.log(`Telegram delivery: ${config.telegram.botToken ? 'ENABLED' : 'DISABLED (logging only — set TELEGRAM_BOT_TOKEN/TELEGRAM_CHAT_ID)'}\n`);

  await runFullScan();
  setInterval(runFullScan, config.normalScanIntervalMs);
  setInterval(runWatchlistScan, config.watchlistScanIntervalMs);
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
