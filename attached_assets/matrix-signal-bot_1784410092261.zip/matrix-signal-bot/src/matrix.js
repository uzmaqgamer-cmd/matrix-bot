// ─────────────────────────────────────────────────────────────
// MARKET CONTEXT MATRIX — the 27 rows, transcribed exactly from
// the reference photo. Do not reorder; row numbers are referenced
// elsewhere (config.divergenceRows, alerts, logs).
// ─────────────────────────────────────────────────────────────

const R = 'RISING';
const S = 'STABLE';
const F = 'FALLING';

// outlook: 'PUMP' | 'DUMP' | 'STABLE' | 'BIG_COMING'
const MATRIX = [
  { row: 1,  oi: R, price: R, funding: R, outlook: 'PUMP',       meaning: 'but late-stage, squeeze risk' },
  { row: 2,  oi: R, price: R, funding: S, outlook: 'PUMP',       meaning: 'healthy' },
  { row: 3,  oi: R, price: R, funding: F, outlook: 'BIG_COMING', meaning: 'fight forming' },
  { row: 4,  oi: F, price: R, funding: R, outlook: 'PUMP',       meaning: 'expensive, fragile' },
  { row: 5,  oi: F, price: R, funding: S, outlook: 'STABLE',     meaning: 'weak bounce, fade risk' },
  { row: 6,  oi: F, price: R, funding: F, outlook: 'STABLE',     meaning: 'rally stalling' },
  { row: 7,  oi: S, price: R, funding: R, outlook: 'PUMP',       meaning: 'mild, low conviction' },
  { row: 8,  oi: S, price: R, funding: S, outlook: 'STABLE',     meaning: 'thin, reversal-prone' },
  { row: 9,  oi: S, price: R, funding: F, outlook: 'BIG_COMING', meaning: 'divergence' },
  { row: 10, oi: R, price: F, funding: R, outlook: 'BIG_COMING', meaning: 'crowded shorts, squeeze risk' },
  { row: 11, oi: R, price: F, funding: S, outlook: 'DUMP',       meaning: 'healthy downtrend' },
  { row: 12, oi: R, price: F, funding: F, outlook: 'BIG_COMING', meaning: 'fight forming' },
  { row: 13, oi: F, price: F, funding: R, outlook: 'BIG_COMING', meaning: 'mixed signal' },
  { row: 14, oi: F, price: F, funding: S, outlook: 'DUMP',       meaning: 'losing steam' },
  { row: 15, oi: F, price: F, funding: F, outlook: 'BIG_COMING', meaning: 'short covering into weakness' },
  { row: 16, oi: S, price: F, funding: R, outlook: 'BIG_COMING', meaning: 'stubborn longs, flush risk' },
  { row: 17, oi: S, price: F, funding: S, outlook: 'DUMP',       meaning: 'weak, low conviction' },
  { row: 18, oi: S, price: F, funding: F, outlook: 'DUMP',       meaning: 'quiet control by shorts' },
  { row: 19, oi: R, price: S, funding: R, outlook: 'BIG_COMING', meaning: 'upside squeeze setup' },
  { row: 20, oi: R, price: S, funding: S, outlook: 'BIG_COMING', meaning: 'direction unclear' },
  { row: 21, oi: R, price: S, funding: F, outlook: 'BIG_COMING', meaning: 'downside squeeze setup' },
  { row: 22, oi: F, price: S, funding: R, outlook: 'BIG_COMING', meaning: 'fragile, unwind risk' },
  { row: 23, oi: F, price: S, funding: S, outlook: 'STABLE',     meaning: 'quiet unwinding' },
  { row: 24, oi: F, price: S, funding: F, outlook: 'BIG_COMING', meaning: 'indecision' },
  { row: 25, oi: S, price: S, funding: R, outlook: 'BIG_COMING', meaning: 'coiling, upside lean' },
  { row: 26, oi: S, price: S, funding: S, outlook: 'STABLE',     meaning: 'true equilibrium' },
  { row: 27, oi: S, price: S, funding: F, outlook: 'BIG_COMING', meaning: 'coiling, downside lean' },
];

/**
 * Look up the matching row for a given (oi, price, funding) classification triple.
 * @param {'RISING'|'STABLE'|'FALLING'} oi
 * @param {'RISING'|'STABLE'|'FALLING'} price
 * @param {'RISING'|'STABLE'|'FALLING'} funding
 */
function lookupRow(oi, price, funding) {
  const match = MATRIX.find(r => r.oi === oi && r.price === price && r.funding === funding);
  if (!match) {
    throw new Error(`No matrix row found for oi=${oi} price=${price} funding=${funding}`);
  }
  return match;
}

module.exports = { MATRIX, lookupRow, DIRECTIONS: { RISING: R, STABLE: S, FALLING: F } };
