const config = require('./config');

async function sendMessage(text) {
  const { botToken, chatId } = config.telegram;
  if (!botToken || !chatId) {
    console.log('[telegram:disabled] would send:\n' + text);
    return;
  }
  const url = `https://api.telegram.org/bot${botToken}/sendMessage`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: chatId, text, parse_mode: 'Markdown' }),
  });
  if (!res.ok) {
    console.error('Telegram send failed:', await res.text());
  }
}

function formatAddedMessage(action) {
  const { symbol, matrixRow, priority } = action;
  return (
    `👁 *WATCHING* — ${symbol}\n` +
    `Row #${matrixRow.row} (${priority} priority) — _${matrixRow.meaning}_\n` +
    `OI: ${matrixRow.oi} | Price: ${matrixRow.price} | Funding: ${matrixRow.funding}\n` +
    `Tracking for resolution...`
  );
}

function formatEscalatedMessage(action) {
  const { symbol, matrixRow, originRow, originPriority, cyclesElapsed } = action;
  const emoji = matrixRow.outlook === 'PUMP' ? '🚀' : '📉';
  return (
    `${emoji} *${matrixRow.outlook}* — ${symbol}\n` +
    `Resolved from Row #${originRow} (${originPriority} priority divergence, ${cyclesElapsed} cycles ago)\n` +
    `Now Row #${matrixRow.row} — _${matrixRow.meaning}_\n` +
    `OI: ${matrixRow.oi} | Price: ${matrixRow.price} | Funding: ${matrixRow.funding}\n` +
    `⚡ Predicted via divergence before confirmation.`
  );
}

module.exports = { sendMessage, formatAddedMessage, formatEscalatedMessage };
