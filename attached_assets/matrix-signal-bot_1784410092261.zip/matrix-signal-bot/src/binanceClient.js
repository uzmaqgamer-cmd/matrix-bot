const config = require('./config');

const BASE = config.binance.futuresBase;

async function getJson(path) {
  const res = await fetch(`${BASE}${path}`);
  if (!res.ok) {
    throw new Error(`Binance API error ${res.status} on ${path}: ${await res.text()}`);
  }
  return res.json();
}

/** Get all USDT-M perpetual symbols currently trading. */
async function getAllPerpSymbols() {
  const data = await getJson('/fapi/v1/exchangeInfo');
  return data.symbols
    .filter(s => s.contractType === 'PERPETUAL' && s.quoteAsset === 'USDT' && s.status === 'TRADING')
    .map(s => s.symbol);
}

/** Get 24h ticker stats for all symbols (used to rank by volume). */
async function get24hTickers() {
  return getJson('/fapi/v1/ticker/24hr');
}

/** Get the top N USDT-M perpetual symbols by 24h quote volume. */
async function getTopSymbolsByVolume(n) {
  const [perpSymbols, tickers] = await Promise.all([getAllPerpSymbols(), get24hTickers()]);
  const perpSet = new Set(perpSymbols);
  return tickers
    .filter(t => perpSet.has(t.symbol))
    .sort((a, b) => parseFloat(b.quoteVolume) - parseFloat(a.quoteVolume))
    .slice(0, n)
    .map(t => t.symbol);
}

/** Kline (candle) close prices, oldest → newest. */
async function getCloseSeries(symbol, interval, limit) {
  const data = await getJson(`/fapi/v1/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`);
  return data.map(k => parseFloat(k[4])); // index 4 = close price
}

/**
 * Open interest history. Binance only exposes OI *history* at fixed periods
 * (5m/15m/30m/1h/2h/4h/6h/12h/1d) via a separate endpoint — not raw klines.
 * We map config.candleInterval to the closest supported OI period.
 */
async function getOpenInterestSeries(symbol, period, limit) {
  const data = await getJson(`/futures/data/openInterestHist?symbol=${symbol}&period=${period}&limit=${limit}`);
  return data.map(d => parseFloat(d.sumOpenInterest));
}

/** Current funding rate (latest) plus recent history for the lookback window. */
async function getFundingRateSeries(symbol, limit) {
  const data = await getJson(`/fapi/v1/fundingRate?symbol=${symbol}&limit=${limit}`);
  return data.map(d => parseFloat(d.fundingRate) * 100); // convert to percentage
}

module.exports = {
  getAllPerpSymbols,
  getTopSymbolsByVolume,
  getCloseSeries,
  getOpenInterestSeries,
  getFundingRateSeries,
};
