const config = require('./config');

/**
 * In-memory watchlist. Key = symbol, value = { row, priority, addedAt, cyclesWatched }
 * For persistence across restarts, swap this Map for a small JSON file or DB later.
 */
const watchlist = new Map();

function isDivergenceRow(rowNum) {
  return config.divergenceRows.includes(rowNum);
}

function isHighPriority(rowNum) {
  return config.highPriorityDivergenceRows.includes(rowNum);
}

/**
 * Process one classification result for a symbol against the watchlist state.
 * Returns an action object describing what happened, for logging/alerting.
 *
 * action.type:
 *  - 'ADDED'      — new divergence detected, now watching
 *  - 'ESCALATED'  — was watching, resolved into PUMP or DUMP → real alert
 *  - 'DROPPED_STABLE' — was watching, resolved into STABLE → false alarm
 *  - 'STILL_WATCHING' — still in a divergence row, keep watching
 *  - 'EXPIRED'    — was watching too long without resolving, drop as stale
 *  - 'NONE'       — not divergent, not on watchlist, nothing to do
 */
function update(symbol, matrixRow) {
  const onList = watchlist.has(symbol);

  if (isDivergenceRow(matrixRow.row)) {
    if (!onList) {
      watchlist.set(symbol, {
        row: matrixRow.row,
        priority: isHighPriority(matrixRow.row) ? 'HIGH' : 'MEDIUM',
        addedAt: Date.now(),
        cyclesWatched: 0,
      });
      return { type: 'ADDED', symbol, matrixRow, priority: isHighPriority(matrixRow.row) ? 'HIGH' : 'MEDIUM' };
    }

    const entry = watchlist.get(symbol);
    entry.cyclesWatched += 1;
    entry.row = matrixRow.row; // divergence flavor may shift row-to-row; keep latest

    if (entry.cyclesWatched >= config.watchlistTimeoutCycles) {
      watchlist.delete(symbol);
      return { type: 'EXPIRED', symbol, matrixRow, cyclesWatched: entry.cyclesWatched };
    }
    return { type: 'STILL_WATCHING', symbol, matrixRow, cyclesWatched: entry.cyclesWatched };
  }

  // Not a divergence row this cycle.
  if (onList) {
    const entry = watchlist.get(symbol);
    watchlist.delete(symbol);
    if (matrixRow.outlook === 'PUMP' || matrixRow.outlook === 'DUMP') {
      const cyclesElapsed = entry.cyclesWatched;
      return {
        type: 'ESCALATED',
        symbol,
        matrixRow,
        originRow: entry.row,
        originPriority: entry.priority,
        cyclesElapsed,
      };
    }
    return { type: 'DROPPED_STABLE', symbol, matrixRow };
  }

  return { type: 'NONE', symbol, matrixRow };
}

function getWatchlistSnapshot() {
  return Array.from(watchlist.entries()).map(([symbol, entry]) => ({ symbol, ...entry }));
}

module.exports = { update, getWatchlistSnapshot, isDivergenceRow, isHighPriority };
