const config = require('./config');
const { DIRECTIONS } = require('./matrix');

/**
 * Classify a % change against a threshold into RISING/STABLE/FALLING.
 */
function classifyByPercentChange(oldest, newest, thresholdPercent) {
  if (oldest === 0) return DIRECTIONS.STABLE; // avoid div-by-zero on degenerate data
  const pctChange = ((newest - oldest) / Math.abs(oldest)) * 100;
  if (pctChange >= thresholdPercent) return DIRECTIONS.RISING;
  if (pctChange <= -thresholdPercent) return DIRECTIONS.FALLING;
  return DIRECTIONS.STABLE;
}

/**
 * Classify funding rate change. Funding is already a small percentage, so we use
 * an absolute percentage-point difference instead of a relative % change
 * (a relative % change on a near-zero funding rate is meaningless/unstable).
 */
function classifyFundingChange(oldest, newest, thresholdAbsPercentPoints) {
  const diff = newest - oldest;
  if (diff >= thresholdAbsPercentPoints) return DIRECTIONS.RISING;
  if (diff <= -thresholdAbsPercentPoints) return DIRECTIONS.FALLING;
  return DIRECTIONS.STABLE;
}

/**
 * Given raw series (oldest → newest) for price, OI, and funding, return the
 * classification triple used to look up the matrix row.
 */
function classify({ priceSeries, oiSeries, fundingSeries }) {
  const priceDir = classifyByPercentChange(
    priceSeries[0], priceSeries[priceSeries.length - 1], config.thresholds.price
  );
  const oiDir = classifyByPercentChange(
    oiSeries[0], oiSeries[oiSeries.length - 1], config.thresholds.oi
  );
  const fundingDir = classifyFundingChange(
    fundingSeries[0], fundingSeries[fundingSeries.length - 1], config.thresholds.funding
  );

  return {
    oi: oiDir,
    price: priceDir,
    funding: fundingDir,
    raw: {
      priceStart: priceSeries[0],
      priceEnd: priceSeries[priceSeries.length - 1],
      oiStart: oiSeries[0],
      oiEnd: oiSeries[oiSeries.length - 1],
      fundingStart: fundingSeries[0],
      fundingEnd: fundingSeries[fundingSeries.length - 1],
    },
  };
}

module.exports = { classify, classifyByPercentChange, classifyFundingChange };
